Requirements: 
  1. MongoDB
  2. NodeJS.

The starting point to the application is app.js
The required packages for the applications can be found in package.json file
it can be executed by the command node app.js.
